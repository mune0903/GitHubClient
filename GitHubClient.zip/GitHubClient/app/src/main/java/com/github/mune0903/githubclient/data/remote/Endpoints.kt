package com.github.mune0903.githubclient.data.remote

const val BASE_URL = "https://api.github.com"

const val EVENT = "/events"