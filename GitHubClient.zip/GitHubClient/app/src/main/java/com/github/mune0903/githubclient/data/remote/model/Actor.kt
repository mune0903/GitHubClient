package com.github.mune0903.githubclient.data.remote.model

data class Actor(
    val login: String,
    val avatar_url: String
)