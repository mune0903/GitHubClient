package com.github.mune0903.githubclient.data.remote.model

data class Repo(
    val name: String,
    val url: String
)